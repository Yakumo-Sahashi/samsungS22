    <link rel="icon" type="image/ico" href="<?=DEP_IMG;?>favicon.png">
    <link rel="stylesheet" href="<?=DEP_CSS;?>b5/bootstrap.css">
    <link rel="stylesheet" href="<?=DEP_CSS;?>main.css">
    <link rel="stylesheet" href="<?=DEP_CSS;?>aos/aos.css">
    <script src="<?=DEP_SCRIPT;?>font_awesome/all.js"></script>
    <script src="<?=DEP_SCRIPT;?>swal/swal.js"></script>
    <script src="<?=DEP_SCRIPT;?>jquery/jquery.js"></script>
    <script src="<?=DEP_SCRIPT;?>poper/popper.js"></script>
    <script src="<?=DEP_SCRIPT;?>b5/bootstrap.js"></script>
    <script src="<?=DEP_SCRIPT;?>aos/aos.js"></script>