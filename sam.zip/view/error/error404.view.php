<?php $title = '404'; ?>
<div class="container mt-5 py-5">
    <div class="row">
        <div class="col text-center">
            <h1 class="display-2">
                Error 404!
            </h1>
            <h1>Pagina no localizada</h1>
        </div>
    </div>
</div>