<div class="contenedor" id="contenedor">
    <div class="loader-container">
        <div class="loader"></div>
        <div class="loader2"></div>
        <img loading="lazy" class="img-load" src="<?=DEP_IMG?>favicon.png" alt="">
    </div>
</div>
<div class="contenedor" id="contenedor2" style="visibility: hidden";>
    <div class="loader-container">
        <div class="loader"></div>
        <div class="loader2"></div>
        <img loading="lazy" class="img-load" src="<?=DEP_IMG?>favicon.png" alt="">
    </div>
</div>
